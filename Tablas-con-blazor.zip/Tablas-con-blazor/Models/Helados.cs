using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Tablas_con_blazor.Models
{
    public class Helados
    {
        public int HEL_Id {get;set;}
        public string NameHel {get;set;}
        public string Sabor {get;set;}
        public int Precio {get;set;}
    
    }
}