using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Tablas_con_blazor.Models;
namespace Tablas_con_blazor.Repositories
{
    public interface IHeladosRepository
    {
                  
        Task<IEnumerable<Helados>> Get();
        Task<Helados> Get(int id);
        Task<Helados> Create(Helados helados);
        Task Update(Helados helados);
        Task Delete(int id);
    }
    }
