using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Tablas_con_blazor.Models;
using Dapper;
using Microsoft.Data.Sqlite;

namespace Tablas_con_blazor.Repositories
{
    public class HeladosRepository : IHeladosRepository
    {
  
      private readonly string _connectionString;

        public HeladosRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("Default");
        }
        public async Task<Helados> Create(Helados helados)
        {
            var sqlQuery = "INSERT INTO HELADOS(NameHel, Sabor, Precio) VALUES (@NameHel, @Sabor, @Precio)";

            using (var connection = new SqliteConnection(_connectionString))
            {
                await connection.ExecuteAsync(sqlQuery, new 
                {
                   
                   helados.NameHel,
                   helados.Sabor,
                   helados.Precio
                });

                return helados;
            }
        }

        public async Task Delete(int id)
        {
            var sqlQuery = $"DELETE from HELADOS WHERE HEL_Id={id}";

            using (var connection = new SqliteConnection(_connectionString))
            {
                await connection.ExecuteAsync(sqlQuery);
            }
        }

        public async Task<IEnumerable<Helados>> Get()
        {
            var sqlQuery = "SELECT * FROM HELADOS";

            using (var connection = new SqliteConnection(_connectionString))
            {
                return await connection.QueryAsync<Helados>(sqlQuery);
            } 
        }

        public async Task<Helados> Get(int id)
        {
            var sqlQuery = "SELECT * FROM HELADOS WHERE Hel_Id=@HeladosId";

            using (var connection = new SqliteConnection(_connectionString))
            {
                return await connection.QueryFirstOrDefaultAsync<Helados>(sqlQuery, new { HeladosId = id });
            }
        }

        public async Task Update(Helados helados)
        {
            var sqlQuery = "UPDATE HELADOS SET NameHel=@NameHel, Sabor=@Sabor, Precio=@Precio WHERE HEL_Id=@HEL_Id";

            using (var connection = new SqliteConnection(_connectionString))
            {
                await connection.ExecuteAsync(sqlQuery, new
                {
                    helados.HEL_Id,
                    helados.NameHel,
                    helados.Sabor,
                    helados.Precio
                });
            }
        }
    }
    }
