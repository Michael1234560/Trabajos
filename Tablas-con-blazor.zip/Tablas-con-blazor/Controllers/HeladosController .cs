using Microsoft.AspNetCore.Mvc;
using Tablas_con_blazor.Models;
using Tablas_con_blazor.Repositories;
namespace Tablas_con_blazor.Controllers;

[ApiController]
[Route("[controller]")]

    public class HeladosController : ControllerBase
    {
        private readonly IHeladosRepository _heladosRepository;
        public HeladosController(IHeladosRepository heladosRepository)
        {
            _heladosRepository = heladosRepository;
        }

        [HttpGet]
        public async Task<IEnumerable<Helados>> GetHelados()
        {
            return await _heladosRepository.Get();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Helados>> GetHelados(int id)
        {
            return await _heladosRepository.Get(id);
        }

        [HttpPost]
        public async Task<ActionResult<Helados>>PostTools([FromBody] Helados helados)
        {
            var newHelados = await _heladosRepository.Create(helados);
            return CreatedAtAction(nameof(GetHelados), new { id = newHelados.HEL_Id }, newHelados);
        }

        [HttpPut]
        public async Task<ActionResult> PutHelados(int id, [FromBody] Helados helados)
        {
            if(id != helados.HEL_Id)
            {
                return BadRequest();
            }

            await _heladosRepository.Update(helados);

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete (int id)
        {
            var HeladosToDelete = await _heladosRepository.Get(id);
            if (HeladosToDelete == null)
                return NotFound();

            await _heladosRepository.Delete(HeladosToDelete.HEL_Id);
            return NoContent();
        }
    }
 

