namespace BlazorApp.Data
{

    public class TareaItem
    {
     
        public DateTime Date { get; set; }
        public string Titulo { get; set;}
        public bool EstadoTerminado { get; set; }


    }


}
